#ifndef LWIP_HDR_TEST_SOCKETS_H
#define LWIP_HDR_TEST_SOCKETS_H

#include "../lwip_check.h"

Suite *sockets_suite(void);

#endif
